<script setup>
import MapView from "./components/MapView.vue";
</script>

<template>
  <MapView />
</template>
