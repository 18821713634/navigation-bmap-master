<script setup>
import { onMounted, onUnmounted, inject, ref, onBeforeUnmount } from "vue";
import * as _ from "lodash";
// 引入three.js
import * as THREE from "three";
// 引入扩展库GLTFLoader.js
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { Raycaster, Vector2 } from "three";

let map = null; // 地图对象
let three = null; // mapvgl.THREE
let view = null; // mapvgl.View
let threeLayer = null; // 三维图层
let loader = null; // 读取模型
let objects = [];
let allModel = null; // 5个人物模型信息
let mouse = null;
let raycaster = null;

const getMapInstance = inject("getMapInstance");

onMounted(async () => {
  map = getMapInstance();
  if (!map) throw new Error("Failed to initialize map.");

  three = mapvgl.THREE;
  mouse = new Vector2();
  raycaster = new Raycaster();

  if (map) {
    view = new mapvgl.View({
      map: map,
    });
    threeLayer = new mapvgl.ThreeLayer(); //创建一个threelayer
    view.addLayer(threeLayer); //添加到view
    console.log("view", view);
    // projection = mapvgl.MercatorProjection; // 获取地图投影对象
    const projection = mapvgl.MercatorProjection;

    allModel = [
      {
        id: 1,
        name: "Barbarian",
        url: "/model/Barbarian/Barbarian.glb",
        position: projection.convertLL2MC(
          new BMapGL.Point(116.308197, 39.983189)
        ),
      },
      {
        id: 2,
        name: "Knight",
        url: "/model/Knight/Knight.glb",
        position: projection.convertLL2MC(
          new BMapGL.Point(116.309424, 39.983171)
        ),
      },
      {
        id: 3,
        name: "Mage",
        url: "/model/Mage/Mage.glb",
        position: projection.convertLL2MC(
          new BMapGL.Point(116.310848, 39.983235)
        ),
      },
      {
        id: 4,
        name: "Rogue",
        url: "/model/Rogue/Rogue.glb",
        position: projection.convertLL2MC(
          new BMapGL.Point(116.311865, 39.983235)
        ),
      },
      {
        id: 5,
        name: "Rogue_Hooded",
        url: "/model/Rogue_Hooded/Rogue_Hooded.glb",
        position: projection.convertLL2MC(
          new BMapGL.Point(116.312712, 39.983318)
        ),
      },
      {
        id: 6,
        name: "bed_frame",
        url: "/model/bed_frame/bed_frame.gltf",
        position: projection.convertLL2MC(
          new BMapGL.Point(116.310909, 39.982932)
        ),
      },
      {
        id: 7,
        name: "chest_gold",
        url: "/model/chest_gold/chest_gold.gltf",
        position: projection.convertLL2MC(
          new BMapGL.Point(116.309446, 39.983037)
        ),
      },
    ];

    // 创建GLTF加载器对象
    loader = new GLTFLoader();

    initGltf();
  }
});

onUnmounted(() => {});

// 初始化模型
function initGltf() {
  for (const model of allModel) {
    console.log("model", model);
    loader.load(
      model.url,
      (gltf) => {
        // 加载成功的回调函数
        console.log("gltf对象场景属性", gltf);
        //调整位置角度等配置
        gltf.scenes[0].position.x = model.position.lng;
        gltf.scenes[0].position.y = model.position.lat;
        gltf.scenes[0].position.z = 0;
        gltf.scenes[0].rotation.set(Math.PI / 2, 0, 0);
        gltf.scenes[0].scale.x = 10;
        gltf.scenes[0].scale.y = 10;
        gltf.scenes[0].scale.z = 10;

        gltf.scene.traverse(function (child) {
          if (child.isMesh) {
            child.frustumCulled = false;
            //模型阴影
            child.castShadow = true;
            //模型自发光
            child.material.emissive = child.material.color;
            child.material.emissiveMap = child.material.map;
          }
        });

        //添加到Threejs图层
        threeLayer.add(gltf.scenes[0]);

        objects.push(gltf.scenes[0]); // 保存引用以便后续清理

        setupInteractivity(gltf.scenes[0]); // 设置交互逻辑
      },
      (xhr) => {
        // 加载过程中的回调函数
      },
      (error) => {
        // 加载错误回调函数
      }
    );
  }
}

function setupInteractivity() {
  // 监听整个文档的鼠标点击事件
  document.addEventListener("mousedown", onDocumentMouseDown, false);
}

function onDocumentMouseDown(event) {
  console.log("event", event);

  // 更新鼠标位置
  mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

  // 更新射线投射器
  raycaster.setFromCamera(mouse, threeLayer.camera);

  // 检查射线与所有对象的相交情况
  const intersects = raycaster.intersectObjects(objects, true); // `true`表示递归检查子对象

  console.log("intersects", intersects);

  if (intersects.length > 0) {
    // 如果有相交对象，选择第一个作为点击目标
    const intersectedObject = intersects[0].object;

    // 执行点击操作，例如打印信息或触发特定逻辑
    console.log("Clicked on:", intersectedObject.name || "Unknown object");

    // 如果你想为每个对象定义特定的行为，可以在这里添加更多逻辑
    // handleObjectClick(intersectedObject);
  }
}

// 假设有一个函数来处理对象点击后的具体行为
function handleObjectClick(object) {
  // 根据需要添加具体的交互逻辑
}
</script>

<template></template>

<style scoped></style>
